#include "list.c"

int main() {
    stack_list();
    List *l = List_create();
}
